using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float _speed = 5f;
    [SerializeField] float _dashCooldown= 1.5f;
    private bool _dashActive = false;

    private CharacterController _controller;
    private Vector2 _moveInput;
    private Vector3 _velocity;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
    }

    public void Move(InputAction.CallbackContext _context)
    {
        _moveInput = _context.ReadValue<Vector2>();
    }

    public void Attack(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {

            Debug.Log("Attack performed!");
        }
    }
    public void Habilidad1(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            Debug.Log("Habilidad1 performed!");
        }
    }

    public void Habilidad2(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            Debug.Log("Habilidad2 performed!");
        }
    }

    public void Dash(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            if (_dashActive == false)
            {
                Debug.Log("Dash performed!");
                Vector2 _dashDirection = transform.right;
                StartCoroutine(IniciarDash(_dashDirection));
                _dashActive = false;
            }
        }
    }

    IEnumerator IniciarDash(Vector2 direction)
    {
        _dashActive = true;
        float _dashTime = 0f;

        while (_dashTime < 3)
        {
            transform.Translate(direction * _speed * 2 * Time.deltaTime, Space.World);
            _dashTime += Time.deltaTime;
            yield return null; 
        }
            yield return new WaitForSeconds(_dashCooldown);
    }

    private void Update()
    {
        Vector3 move = new Vector3(_moveInput.x, _moveInput.y, 0);
        _controller.Move(move * _speed * Time.deltaTime);

        _velocity.y += Physics.gravity.y * Time.deltaTime;
    }
}

