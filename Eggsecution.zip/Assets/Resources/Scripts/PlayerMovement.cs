using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb2D;
    public float _speed;
    
    private Vector2 _moveDirection;

    public InputActionReference _move;
    public InputActionReference _attack;

    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        _moveDirection = _move.action.ReadValue<Vector2>();
    }

    private void FixedUpdate()
    {
        rb2D.linearVelocity = new Vector2(_moveDirection.x * _speed, _moveDirection.y * _speed);
    }

    private void OnEnable()
    {
        _attack.action.started += Attack;
    }

    private void OnDisable()
    {
        _attack.action.started -= Attack;
    }
    private void Attack(InputAction.CallbackContext obj)
    {
        Debug.Log("PUTITO");
    }
}
