using UnityEngine;
using UnityEngine.Tilemaps; // Para Tilemap y TileBase

// Se pone en el Tilemap de las PAREDES. Al empezar el juego crea un BoxCollider 3D
// por cada baldosa, para que los CharacterController (física 3D) choquen con ellas.
// (Un Tilemap Collider 2D no sirve: la física 2D y la 3D no chocan entre sí)
[RequireComponent(typeof(Tilemap))] // Unity no deja poner este script en un objeto sin Tilemap
public class ColisionesTilemap3D : MonoBehaviour
{
    [SerializeField] private float _profundidad = 2f;       // Grosor en Z de cada pared (los personajes están en Z = 0)
    [SerializeField] private TileBase[] _tilesSinColision;  // Opcional: baldosas que NO deben chocar (p. ej., el suelo si está en este mismo Tilemap)

    private void Awake()
    {
        Tilemap tilemap = GetComponent<Tilemap>();

        // Un objeto hijo vacío que guardará todos los colliders (así no se llena la Hierarchy de objetos)
        GameObject contenedor = new GameObject("Colisiones3D");
        contenedor.transform.SetParent(transform, false); // false = mismo sitio, giro y escala que el Tilemap

        tilemap.CompressBounds();               // Ajusta los límites del Tilemap a las celdas que de verdad tienen baldosa
        BoundsInt limites = tilemap.cellBounds; // Rectángulo de celdas que hay que recorrer
        int creados = 0;

        // allPositionsWithin recorre TODAS las celdas del rectángulo, una a una (x, y)
        foreach (Vector3Int celda in limites.allPositionsWithin)
        {
            TileBase tile = tilemap.GetTile(celda);
            if (tile == null) continue;          // Celda vacía → no hay pared
            if (EsSinColision(tile)) continue;   // Es una baldosa marcada como "sin colisión" (suelo) → saltar

            // Se pueden poner VARIOS BoxCollider en el mismo objeto: uno por baldosa
            BoxCollider caja = contenedor.AddComponent<BoxCollider>();

            // GetCellCenterWorld da el centro de la celda en coordenadas del mundo;
            // "center" del collider va en coordenadas LOCALES del contenedor → hay que convertirlo
            caja.center = contenedor.transform.InverseTransformPoint(tilemap.GetCellCenterWorld(celda));
            caja.size = new Vector3(tilemap.cellSize.x, tilemap.cellSize.y, _profundidad);
            creados++;
        }

        Debug.Log(name + ": creados " + creados + " colliders 3D de pared");
    }

    // ¿Esta baldosa está en la lista de las que no chocan?
    private bool EsSinColision(TileBase tile)
    {
        if (_tilesSinColision == null) return false;

        foreach (TileBase t in _tilesSinColision)
        {
            if (t == tile) return true;
        }
        return false;
    }
}
