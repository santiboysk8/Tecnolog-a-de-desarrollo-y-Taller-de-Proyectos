using UnityEngine;

// Va en TODOS los prefabs de ataque: C_Punch, C_Sword, S_Bala, S_Fireball.
// Necesita un Collider (3D) con "Is Trigger" y un Rigidbody con "Is Kinematic"
public class Golpe : MonoBehaviour
{
    [SerializeField] private float _danio = 10f;              // Cuánta vida quita
    [SerializeField] private bool _destruirAlGolpear = false; // true en balas y bolas de fuego; false en puñetazos y espadazos

    private Bando _bando;              // De quién es este golpe (lo pone quien lo crea)
    private bool _configurado = false; // Si nadie ha dicho de quién es, no hace daño (por seguridad)

    // La llama Personaje.CrearAtaque justo después de crear el golpe
    public void Configurar(Bando bando)
    {
        _bando = bando;
        _configurado = true;
    }

    // Unity lo llama cuando otro collider entra en este trigger
    private void OnTriggerEnter(Collider other)
    {
        if (!_configurado) return;

        // Busca un Personaje en lo que ha tocado (o en sus padres, por si el collider está en un hijo).
        // Encuentra igual a un PlayerMovement que a un EnemyMelee: los dos SON Personaje (polimorfismo)
        Personaje personaje = other.GetComponentInParent<Personaje>();

        if (personaje == null) return;              // No es un personaje (pared, otro golpe...)
        if (personaje.Bando == _bando) return;      // Es de mi bando → sin fuego amigo
        if (personaje.EstaMuerto) return;           // Ya está muerto

        personaje.RecibirDanio(_danio);

        if (_destruirAlGolpear)
        {
            Destroy(gameObject); // La bala desaparece al impactar
        }
    }
}
