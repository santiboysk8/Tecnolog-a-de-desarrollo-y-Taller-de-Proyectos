using UnityEngine;

// abstract → no existe un "enemigo genérico", solo EnemyMelee (y luego EnemyShooter...)
public abstract class Enemigo : Personaje
{
    // Todos los enemigos son del bando Enemigo
    public override Bando Bando => Bando.Enemigo;

    // Un solo Update para todos los enemigos: comprueba lo común y deja que cada hijo haga lo suyo
    private void Update()
    {
        if (_muerto) return;
        Comportamiento();
    }

    // abstract → cada tipo de enemigo DEBE escribir qué hace en cada frame
    protected abstract void Comportamiento();

    // Atajo para buscar al jugador más cercano
    protected Transform BuscarJugadorCercano()
    {
        return PlayerMovement.JugadorMasCercano(transform.position);
    }

    // Crea un ataque delante del enemigo, girado hacia el objetivo (golpe o bala)
    protected GameObject CrearHacia(GameObject prefab, Transform objetivo, float distancia)
    {
        if (prefab == null || objetivo == null) return null;

        Vector3 dir = (objetivo.position - transform.position).normalized; // Dirección hacia el objetivo (longitud 1)
        float angulo = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - 90f;   // Para que el eje Y del prefab mire al objetivo
        return CrearAtaque(prefab, transform.position + dir * distancia, Quaternion.Euler(0, 0, angulo)); // Heredado de Personaje: pone el bando
    }

    // Al morir: lo común (base) y después desaparece
    protected override void Morir()
    {
        base.Morir();
        Destroy(gameObject);
    }
}
