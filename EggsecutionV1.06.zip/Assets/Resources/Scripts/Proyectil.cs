using UnityEngine;

// Hace avanzar el objeto hacia su eje Y y lo destruye pasado un tiempo.
// Va en S_Bala y S_Fireball (antes cada uno tenía su script, BulletController y FireballController, pero eran idénticos)
public class Proyectil : MonoBehaviour
{
    [SerializeField] private float _speed = 5f;          // Velocidad de avance
    [SerializeField] private float _timeToDestroy = 3.5f; // Segundos hasta desaparecer si no choca con nada

    private void Start()
    {
        Destroy(gameObject, _timeToDestroy); // Igual que en los roles: "destrúyete dentro de X segundos"
    }

    private void Update()
    {
        // Avanza por su eje Y local, que es el que mira hacia donde se apuntó (por el -90 del ángulo)
        transform.Translate(_speed * Time.deltaTime * Vector3.up);
    }
}
