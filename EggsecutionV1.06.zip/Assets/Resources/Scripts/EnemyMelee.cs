using UnityEngine; // Da acceso a MonoBehaviour, Vector2, Time, Debug, etc.

// Enemigo cuerpo a cuerpo: cuando un jugador se acerca le hace focus,
// lo persigue y le ataca cuando está a rango.
public class EnemyMelee : Enemigo // CAMBIA: antes MonoBehaviour. Ahora hereda de Enemigo (y por tanto de Personaje: tiene vida)
{
    // ---------- VARIABLES DEL INSPECTOR ----------
    // [SerializeField] hace que una variable private aparezca en el Inspector para ajustarla sin tocar código

    [SerializeField] private float _speed = 2f;                // Velocidad a la que persigue (unidades por segundo)
    [SerializeField] private float _distanciaDeteccion = 5f;   // Si un jugador se acerca a menos de esto, le hace focus
    [SerializeField] private float _distanciaPerderFocus = 8f; // Si el objetivo se aleja más de esto, lo suelta (debe ser MAYOR que la de detección)
    [SerializeField] private float _distanciaAtaque = 1.2f;    // A esta distancia deja de andar y empieza a atacar
    [SerializeField] private float _tiempoEntreAtaques = 1f;   // Segundos de espera entre un golpe y el siguiente (cooldown)

    [SerializeField] private GameObject _ataquePrefab;         // Prefab que aparece al golpear (puedes usar C_Punch o C_Sword). Si está vacío, solo hace Debug.Log
    [SerializeField] private float _spawnDistance = 0.8f;      // A qué distancia del enemigo aparece el golpe
    [SerializeField] private float _duracionGolpe = 0.5f;      // NUEVO: segundos que dura el golpe antes de destruirse (C_Punch ya no se destruye solo)

    // ---------- VARIABLES INTERNAS ----------
    private Transform _objetivo;      // El jugador al que tiene fijado. null = no tiene a nadie
    private float _siguienteAtaque;   // Momento (en segundos de juego) a partir del cual puede volver a atacar

    // CAMBIA: antes "private void Update()". Ahora el Update está en Enemigo (comprueba si está muerto)
    // y llama a este método, que es la implementación obligatoria del abstract Comportamiento()
    protected override void Comportamiento()
    {
        ActualizarFocus();            // Primero decide a quién persigue (o si suelta al que tenía)

        if (_objetivo == null) return; // Si no tiene a nadie, no hace nada más este frame

        // Distancia 2D entre el enemigo y su objetivo
        float distancia = Vector2.Distance(transform.position, _objetivo.position);

        if (distancia > _distanciaAtaque) // ¿Está lejos para golpear?
        {
            // Se acerca un paso hacia el objetivo.
            // MoveTowards nunca se pasa del destino.
            // _speed * Time.deltaTime hace que vaya igual de rápido a 30 fps que a 144 fps
            transform.position = Vector2.MoveTowards(transform.position, _objetivo.position, _speed * Time.deltaTime);
        }
        else if (Time.time >= _siguienteAtaque) // Está cerca. ¿Ha pasado ya el cooldown?
        {
            Atacar();                                           // Golpea
            _siguienteAtaque = Time.time + _tiempoEntreAtaques; // Y apunta cuándo puede volver a golpear
            // Time.time = segundos que lleva el juego en marcha. Ejemplo:
            // golpea en el segundo 10 con cooldown 1 → no puede volver a golpear hasta el segundo 11
        }
    }

    // Decide si coge, mantiene o suelta un objetivo
    private void ActualizarFocus()
    {
        // CASO 1: ya tiene objetivo → comprobar si lo tiene que soltar
        if (_objetivo != null)
        {
            bool desactivado = !_objetivo.gameObject.activeInHierarchy;   // ¿El jugador se ha desactivado (por ejemplo, muerto)?
            bool muyLejos = Vector2.Distance(transform.position, _objetivo.position) > _distanciaPerderFocus; // ¿Se ha escapado?

            if (desactivado || muyLejos) // Si pasa cualquiera de las dos
            {
                _objetivo = null;        // Lo suelta. El próximo frame volverá a buscar
            }
            return; // Si tiene objetivo NO busca otro: se queda con el que fijó (eso es el "focus")
        }

        // CASO 2: no tiene objetivo → buscar al jugador más cercano
        Transform cercano = BuscarJugadorCercano(); // CAMBIA: herramienta heredada de Enemigo (por dentro llama a PlayerMovement.JugadorMasCercano)

        // ¿Hay algún jugador Y está dentro del rango de detección?
        if (cercano != null && Vector2.Distance(transform.position, cercano.position) <= _distanciaDeteccion)
        {
            _objetivo = cercano;                                   // Lo fija
            Debug.Log(name + " hace focus a " + _objetivo.name);   // Para que veas en consola cuándo pasa
        }
    }

    // Hace el golpe
    private void Atacar()
    {
        Debug.Log(name + " ataca a " + _objetivo.name);

        // CAMBIA: CrearHacia (heredado de Enemigo) calcula dirección y ángulo, crea el golpe
        // y le pone el bando Enemigo (para que dañe a los jugadores y no a otros enemigos).
        // Si _ataquePrefab está vacío devuelve null
        GameObject golpe = CrearHacia(_ataquePrefab, _objetivo, _spawnDistance);

        if (golpe != null)
        {
            Destroy(golpe, _duracionGolpe); // Lo destruye pasado un tiempo (antes lo hacía PunchController dentro del prefab)
        }
    }

   
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;                                      // Amarillo = detección
        Gizmos.DrawWireSphere(transform.position, _distanciaDeteccion);
        Gizmos.color = Color.gray;                                        // Gris = perder focus
        Gizmos.DrawWireSphere(transform.position, _distanciaPerderFocus);
        Gizmos.color = Color.red;                                         // Rojo = ataque
        Gizmos.DrawWireSphere(transform.position, _distanciaAtaque);
    }
}
