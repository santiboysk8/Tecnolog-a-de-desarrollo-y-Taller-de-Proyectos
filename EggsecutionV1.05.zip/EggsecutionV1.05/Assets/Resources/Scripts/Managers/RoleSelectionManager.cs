using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class RoleSelectionManager : MonoBehaviour
{
    public static RoleSelectionManager Instance;

    [SerializeField] private Button _wizardButton;
    [SerializeField] private Button _shooterButton;
    [SerializeField] private Button _boxerButton;
    [SerializeField] private Button _sworderButton;

    private void Awake()
    {
        if (RoleSelectionManager.Instance == null)
            RoleSelectionManager.Instance = this;
        else
            Destroy(gameObject);
    }

    private void OnEnable()
    {
        _wizardButton.onClick.AddListener(OnPlay);
    }

    private void OnDisable()
    {
        _wizardButton.onClick.RemoveListener(OnPlay);
    }

    private void OnPlay()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(3);
    }

}
