using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
    public static MenuManager Instance;

    [SerializeField] private Button _playButton;
    [SerializeField] private Button _optionButton;
    [SerializeField] private Button _creditsButton;
    [SerializeField] private Button _exitButton;

    private void Awake()
    {
        if (MenuManager.Instance == null)
            MenuManager.Instance = this;
        else
            Destroy(gameObject);
    }

    private void OnEnable()
    {
        _playButton.onClick.AddListener(OnPlay);
    }

    private void OnDisable()
    {
        _playButton.onClick.RemoveListener(OnPlay);
    }

    private void OnPlay()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(1);
    }

}
