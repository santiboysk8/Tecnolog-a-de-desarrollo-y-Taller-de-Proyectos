using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class PlayerSelectionManager : MonoBehaviour
{
    public static PlayerSelectionManager Instance;

    [SerializeField] private Button _singlePlayerButton;
    [SerializeField] private Button _multiPlayerButton;

    private void Awake()
    {
        if (PlayerSelectionManager.Instance == null)
            PlayerSelectionManager.Instance = this;
        else
            Destroy(gameObject);
    }

    private void OnEnable()
    {
        _multiPlayerButton.onClick.AddListener(OnPlay);
    }

    private void OnDisable()
    {
        _multiPlayerButton.onClick.RemoveListener(OnPlay);
    }

    private void OnPlay()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(2);
    }

}
