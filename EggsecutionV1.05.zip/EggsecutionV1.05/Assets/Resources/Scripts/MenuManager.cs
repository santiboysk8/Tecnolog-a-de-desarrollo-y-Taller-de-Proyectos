using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [SerializeField] private Button _playButton;
    [SerializeField] private Button _optionButton;
    [SerializeField] private Button _creditsButton;
    [SerializeField] private Button _exitButton;

    private void Awake()
    {
        if (GameManager.Instance == null)
            GameManager.Instance = this;
        else
            Destroy(gameObject);
    }

    private void OnEnable()
    {
        _playButton.onClick.AddListener(OnPlay);
    }

    private void OnDisable()
    {
        _playButton.onClick.RemoveListener(OnPlay);
    }

    private void OnPlay()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(3);
    }

}
