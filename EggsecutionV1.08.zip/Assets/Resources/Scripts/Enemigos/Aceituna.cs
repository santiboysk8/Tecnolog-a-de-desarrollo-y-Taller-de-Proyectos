using UnityEngine;

// Aceituna: tirador con un disparo recto
public class Aceituna : EnemigoTirador
{
    [SerializeField] private GameObject _balaAceituna;

    protected override void Disparar()
    {
        Debug.Log(name + " dispara a " + _objetivo.name);
        CrearHacia(_balaAceituna, _objetivo, _spawnDistance);
    }
}