using UnityEngine;

// ESPADACHÍN: igual que el mago pero con estamina y espadazos
public class RolEspadachin : Rol
{
    [SerializeField] private GameObject _swordCollider;          // C_Sword
    [SerializeField] private float _costeEstamina = 10f;
    [SerializeField] private float _regeneracionPorSegundo = 15f; // Se recupera más rápido que el maná
    [SerializeField] private float _duracionEspadazo = 1f;       // NUEVO: lo que antes era _timeToDestroy en SwordController

    public override string NombreRecurso => "Estamina";

    private void Update()
    {
        if (_recurso < _recursoMaximo)
        {
            Recuperar(_regeneracionPorSegundo * Time.deltaTime);
        }
    }

    public override void Atacar()
    {
        if (Gastar(_costeEstamina))
        {
            // CAMBIA: SpawnHaciaApuntado DEVUELVE el objeto que crea (por eso era "return Instantiate(...)").
            // Lo guardamos en una variable para poder hacer cosas con él
            GameObject espadazo = _jugador.SpawnHaciaApuntado(_swordCollider);

            // NUEVO: Destroy con dos parámetros = "destrúyelo dentro de X segundos".
            // Hace lo mismo que el Invoke + Destroy de SwordController, pero en una línea
            Destroy(espadazo, _duracionEspadazo);

            Debug.Log("Estamina: " + _recurso);
        }
    }
}
