using UnityEngine;

// Hace avanzar el proyectil con física 2D y lo destruye pasado un tiempo.
// Va en S_Bala y S_Fireball
[RequireComponent(typeof(Rigidbody2D))] // NUEVO: Unity añade un Rigidbody2D solo si no lo tiene
public class Proyectil : MonoBehaviour
{
    [SerializeField] private float _speed = 5f;          // Velocidad de avance
    [SerializeField] private float _timeToDestroy = 3.5f; // Segundos hasta desaparecer si no choca con nada

    private void Start()
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic; // Kinematic = se mueve por su velocidad, sin gravedad y sin que nada lo empuje

        // transform.up = su eje Y en el mundo (el que mira hacia donde se apuntó, por el -90 del ángulo).
        // Se pone UNA vez: un cuerpo Kinematic mantiene su velocidad para siempre
        rb.linearVelocity = transform.up * _speed;

        Destroy(gameObject, _timeToDestroy); // "destrúyete dentro de X segundos"
    }

    // CAMBIA: ya no hay Update con transform.Translate; lo mueve la física
}
