using UnityEngine;

// Va en TODOS los prefabs de ataque: C_Punch, C_Sword, S_Bala, S_Fireball.
// Necesita un Collider 2D con "Is Trigger" (las balas además un Rigidbody 2D Kinematic, que pone Proyectil)
public class Golpe : MonoBehaviour
{
    [SerializeField] private float _danio = 10f;              // Cuánta vida quita
    [SerializeField] private bool _destruirAlGolpear = false; // true en balas y bolas de fuego; false en puñetazos y espadazos

    private Bando _bando;              // De quién es este golpe (lo pone quien lo crea)
    private bool _configurado = false; // Si nadie ha dicho de quién es, no hace daño (por seguridad)

    // La llama Personaje.CrearAtaque justo después de crear el golpe
    public void Configurar(Bando bando)
    {
        _bando = bando;
        _configurado = true;
    }

    // CAMBIA: OnTriggerEnter2D y Collider2D (antes OnTriggerEnter y Collider, de la física 3D).
    // Unity lo llama cuando otro collider 2D entra en este trigger
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!_configurado) return;

        // Busca un Personaje en lo que ha tocado (o en sus padres, por si el collider está en un hijo).
        // Encuentra igual a un PlayerMovement que a un EnemyMelee: los dos SON Personaje (polimorfismo)
        Personaje personaje = other.GetComponentInParent<Personaje>();

        if (personaje == null)
        {
            // NUEVO: no es un personaje. Si es algo SÓLIDO (no trigger: una pared) y soy una bala → desaparezco.
            // Los otros ataques son triggers, así que una bala no se destruye al cruzarse con otra
            if (_destruirAlGolpear && !other.isTrigger)
            {
                Destroy(gameObject);
            }
            return;
        }
        if (personaje.Bando == _bando) return;      // Es de mi bando → sin fuego amigo
        if (personaje.EstaMuerto) return;           // Ya está muerto

        personaje.RecibirDanio(_danio);

        if (_destruirAlGolpear)
        {
            Destroy(gameObject); // La bala desaparece al impactar
        }
    }
}
