using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
    public static MenuManager Instance;

    [SerializeField] private Button _playButton;
    [SerializeField] private Button _optionButton;
    [SerializeField] private Button _creditsButton;
    [SerializeField] private Button _exitButton;
    [SerializeField] private string _escenaSiguiente = "PlayerSelection"; // NUEVO: por NOMBRE, no por número

    private void Awake()
    {
        if (MenuManager.Instance == null)
            MenuManager.Instance = this;
        else
            Destroy(gameObject);
    }

    private void OnEnable()
    {
        _playButton.onClick.AddListener(OnPlay);
        _exitButton.onClick.AddListener(OnExit); // NUEVO: el botón Exit ya hace algo
    }

    private void OnDisable()
    {
        _playButton.onClick.RemoveListener(OnPlay);
        _exitButton.onClick.RemoveListener(OnExit);
    }

    private void OnPlay()
    {
        Time.timeScale = 1;
        // CAMBIA: antes LoadScene(1). Con el nombre no se rompe si cambia el orden de la lista de escenas
        SceneManager.LoadScene(_escenaSiguiente);
    }

    // NUEVO: cierra el juego (en el editor no hace nada, por eso el Debug.Log)
    private void OnExit()
    {
        Debug.Log("Salir del juego");
        Application.Quit();
    }

    // [ANTIGUO] Versión anterior de OnPlay (cargaba por número). Borrar cuando todo funcione
    //private void OnPlay()
    //{
    //    Time.timeScale = 1;
    //    SceneManager.LoadScene(1);
    //}
    // [FIN ANTIGUO]
}
