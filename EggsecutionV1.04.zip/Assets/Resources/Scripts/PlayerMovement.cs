using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    //Movimiento común
    [SerializeField] float _speed = 5f;
    [SerializeField] float _dashCooldown= 1.5f;
    [SerializeField] float _dashDuration = 0.2f;
    [SerializeField] float _dashSpeedMultiplier = 2f;
    [SerializeField] private Camera _camera;
    private Vector3 _objective;

    [SerializeField] private Transform _visual;
    [SerializeField] private float _spawnDistance = 1.25f;
    private Vector2 _aimDirection = Vector2.right;
    private PlayerInput _playerInput;


    //Variables mago
    private float _mana = 100f;
    [SerializeField] private GameObject _fireball;

    [SerializeField] private bool _wizardActive = false;

    //Variables espadachín
    private float _estamina = 100f;
    [SerializeField] private GameObject _swordCollider;

    [SerializeField] private bool _sworderActive = false;

    //Variables pistolero
    private int _balas = 30;
    [SerializeField] private GameObject _bullets;

    [SerializeField] private bool _shooterActive = false;

    //Variables luchador
    private float _furia = 0f;
    [SerializeField] private GameObject _punchCollider;

    [SerializeField] private bool _fighterActive = false;




    private bool _dashActive = false;
    private bool _isDashing = false;

    private CharacterController _controller;
    private Vector3 _moveInput;
    private Vector2 _lastMoveDirection = Vector2.right;
    private Vector3 _velocity;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
        _playerInput = GetComponent<PlayerInput>();
        
        if(_camera == null)
        {
            _camera = Camera.main;
        }
    }
    public void Aim (InputAction.CallbackContext _context) //Apuntado del personaje con el Mouse y Joystick
    {
        Vector2 stick = _context.ReadValue<Vector2>();
        if (stick.sqrMagnitude > 0.04f)
        {
            _aimDirection = stick.normalized;
  
        }
    }

    public void ActualizarApuntado() //Apuntado del mouse
    {
        bool usaRaton = _playerInput.currentControlScheme == "Teclado";
        if(usaRaton && Mouse.current != null)
        {
            Vector3 mousePos = Mouse.current.position.ReadValue();
            mousePos.z = Mathf.Abs(_camera.transform.position.z);
            _objective = _camera.ScreenToWorldPoint(mousePos);

            Vector2 dir = _objective - transform.position;
            if(dir.sqrMagnitude > 0.01f)
            {
                _aimDirection = dir.normalized;
            }
        }

        float angulo = Mathf.Atan2(_aimDirection.y, _aimDirection.x) * Mathf.Rad2Deg - 90f;
        _visual.rotation = Quaternion.Euler(0, 0, angulo);
    }

    private GameObject SpawnHaciaApuntado(GameObject prefab)
    {
        Vector3 dir = new Vector3(_aimDirection.x, _aimDirection.y, 0);
        Vector3 pos = transform.position + dir * _spawnDistance;
        return Instantiate(prefab, pos, _visual.rotation);
    }
    public void Move(InputAction.CallbackContext _context)
    {
        _moveInput = _context.ReadValue<Vector2>();
    }

    public void Attack(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            if (_wizardActive == true && _mana >= 10)
            {
                SpawnHaciaApuntado(_fireball);
                _mana = 10;
                Debug.Log("Mana: " + _mana);
            }
            else if (_sworderActive == true && _estamina >= 10)
            {
                SpawnHaciaApuntado(_swordCollider);
                _estamina -= 10;
                Debug.Log("Estamina: " + _estamina);
            }
            else if (_shooterActive == true && _balas >= 1)
            {
                SpawnHaciaApuntado(_bullets);
                _balas -= 1;
                Debug.Log("Balas: " + _balas);
                if (_balas == 1)
                {
                    Debug.Log("Recargando");
                    new WaitForSeconds(1.4f);
                    _balas = 30;
                    Debug.Log("Recarga completa");
                }
            }
            else if (_fighterActive == true)
            {
                SpawnHaciaApuntado(_punchCollider);
                _furia += 5;
                if (_furia > 100) 
                { 
                    _furia = 100; 
                }
                Debug.Log("Furia: " + _furia);
            }
            Debug.Log("Attack performed!");
        }
    }
    public void Habilidad1(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            Debug.Log("Habilidad1 performed!");
        }
    }

    public void Habilidad2(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            Debug.Log("Habilidad2 performed!");
        }
    }

    public void Dash(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            if (_dashActive == false)
            {
                Debug.Log("Dash performed!");
                Vector2 _dashDirection = _lastMoveDirection;
                StartCoroutine(IniciarDash(_dashDirection));
            }
        }
    }


    IEnumerator IniciarDash(Vector2 direction)
    {
        _dashActive = true;
        _isDashing = true;
        float _dashTime = 0f;

        while (_dashTime < _dashDuration)
        {
            Vector3 move = new Vector3(direction.x, direction.y, 0);
            _controller.Move(move * _speed * _dashSpeedMultiplier * Time.deltaTime);
            _dashTime += Time.deltaTime;
            yield return null;
        }

        _isDashing = false;
        yield return new WaitForSeconds(_dashCooldown);
        _dashActive = false;
    }

    private void Update()
    {
        ActualizarApuntado();

        float anguloRadianes = Mathf.Atan2(_objective.y - transform.position.y, _objective.x - transform.position.x);
        float anguloGrados = (180 / Mathf.PI) * anguloRadianes - 90;
        if (_moveInput.sqrMagnitude > 0.01f)
        {
            _lastMoveDirection = _moveInput.normalized;
        }

        if (!_isDashing)
        {
            Vector3 move = new Vector3(_moveInput.x, _moveInput.y, 0);
            _controller.Move(move * _speed * Time.deltaTime);
        }

        _velocity.y += Physics.gravity.y * Time.deltaTime;

    }
}

