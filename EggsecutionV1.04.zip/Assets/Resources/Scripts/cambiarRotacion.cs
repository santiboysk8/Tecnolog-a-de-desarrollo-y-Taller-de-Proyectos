using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cambiarRotacion : MonoBehaviour
{
    private Vector3 _object;
    [SerializeField] private Camera _camera;

    // Update is called once per frame
    private void Update()
    {
        _object = _camera.ScreenToWorldPoint(Input.mousePosition);

        float anguloRadianes = Mathf.Atan2(_object.y - transform.position.y, _object.x - transform.position.x);
        float anguloGrados = (180 / Mathf.PI) * anguloRadianes - 90;
        transform.rotation = Quaternion.Euler(0, 0, anguloGrados);
    }
}
