using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInputManager : MonoBehaviour
{

    [SerializeField] private GameObject _playerPrefab;
    [SerializeField] private Transform[] _spawnPoints;

    private bool _playerWASD = false;
    private bool _playerGamepad = false;

  
    void Update()
    {
        if(Keyboard.current != null && !_playerWASD && Keyboard.current.fKey.wasPressedThisFrame)
        {
            PlayerInput player;
            if(Mouse.current != null)
            {
                player = PlayerInput.Instantiate(_playerPrefab,
                                                 controlScheme: "Teclado",
                                                 pairWithDevices: new InputDevice[]{Keyboard.current, Mouse.current});
            }
            else
            {
                player = PlayerInput.Instantiate(_playerPrefab, controlScheme: "Teclado", pairWithDevice: Keyboard.current);
            }
            if(_spawnPoints.Length > 0)
            {
                player.transform.position = _spawnPoints[0].position;
            }

            _playerWASD = true;
            Debug.Log("Player instantiated with Keyboard + Mouse Controls.");

        }

        foreach(var gamePad in Gamepad.all)
        {
            if(!_playerGamepad && gamePad.selectButton.wasPressedThisFrame)
            {
                var player = PlayerInput.Instantiate(_playerPrefab, controlScheme: "GamePad", pairWithDevice: gamePad);
                if(_spawnPoints.Length > 1)
                {
                    player.transform.position = _spawnPoints[1].position;
                }
                
                _playerGamepad = true;
                Debug.Log("Player instantiated with Mando");
            }
        }
    }
}
