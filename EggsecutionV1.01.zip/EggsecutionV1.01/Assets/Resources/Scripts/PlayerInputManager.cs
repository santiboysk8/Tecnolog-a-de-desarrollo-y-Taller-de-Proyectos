using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInputManager : MonoBehaviour
{

    [SerializeField] private GameObject _playerPrefab;
    [SerializeField] private Transform[] _spawnPoints;

    private bool _playerWASD = false;
    private bool _playerGamepad = false;

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Keyboard.current == null) return;

        if (!_playerWASD && Keyboard.current.spaceKey.wasPressedThisFrame)
        {
            var player = PlayerInput.Instantiate(_playerPrefab, controlScheme: "Teclado",
                pairWithDevice: Keyboard.current);

            if (_spawnPoints.Length > 0)
            {
               player.transform.position = _spawnPoints[0].position;
            }

            _playerWASD = true;
            Debug.Log("Player instantiated with WASD controls.");
        }

        foreach (var gamePad in Gamepad.all)
        {
            if (gamePad.buttonEast.wasPressedThisFrame && !_playerGamepad)
            {
                PlayerInput.Instantiate(_playerPrefab, controlScheme: "Gamepad",
                    pairWithDevice: gamePad);

                _playerGamepad = true;
                Debug.Log("Player instantiated with Gamepad controls.");
            }
        }
    }
}
