using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public Transform _player1;
    public Transform _player2;

    public float _speed = 2f;
    public float _distanceDeteccion = 5f;

    void Update()
    {
        if (_player1 == null && _player2 == null)
            return;

        float _distancia1 = Vector2.Distance(transform.position, _player1.position);
        float _distancia2 = Vector2.Distance(transform.position, _player2.position);

        Transform _jugadorObjetivo = null;

        
        if (_distancia1 <= _distanceDeteccion || _distancia2 <= _distanceDeteccion)
        {
            
            if (_distancia1 <= _distancia2)
                _jugadorObjetivo = _player1;
            else
                _jugadorObjetivo = _player2;
        }

        
        if (_jugadorObjetivo != null)
        {
            transform.position = Vector2.MoveTowards(
                transform.position,
                _jugadorObjetivo.position,
                _speed * Time.deltaTime
            );
        }
    }
}
