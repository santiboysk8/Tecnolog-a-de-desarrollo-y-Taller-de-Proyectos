using UnityEngine;

public class FireballController : MonoBehaviour
{
    [SerializeField] private float _speed = 5f;
    [SerializeField] private float _timeToDestroy = 3.5f;

    private void Start()
    {
        Invoke(nameof(Destroy), _timeToDestroy);
    }

    private void Update()
    {
        transform.Translate(_speed * Time.deltaTime * Vector3.up);
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }
}