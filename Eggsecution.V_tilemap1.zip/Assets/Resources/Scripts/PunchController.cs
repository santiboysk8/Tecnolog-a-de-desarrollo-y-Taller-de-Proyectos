using UnityEngine;

public class PunchController : MonoBehaviour
{
    [SerializeField] private float _timeToDestroy = 0.5f;

    private void Start()
    {
        Invoke(nameof(Destroy), _timeToDestroy);
    }

    private void Update()
    {
        
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }
}