using UnityEngine;

public class SwordController : MonoBehaviour
{
    [SerializeField] private float _timeToDestroy = 1f;

    private void Start()
    {
        Invoke(nameof(Destroy), _timeToDestroy);
    }

    private void Update()
    {

    }

    private void Destroy()
    {
        Destroy(gameObject);
    }
}