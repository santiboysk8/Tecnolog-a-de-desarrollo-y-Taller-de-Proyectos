using System.Collections;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class WizardScript : MonoBehaviour
{
    private float _mana = 100;
    private CharacterController _controller;
    [SerializeField] private GameObject _fireball;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
    }
    void Start()
    {

    }

    public void Attack(InputAction.CallbackContext _context)
    {
        if (_context.performed)
        {
            GameObject newFireball = GameObject.Instantiate(_fireball);
            newFireball.transform.position = transform.position + new Vector3(0, 1.25f, 0);
            _mana -= 10;
            Debug.Log("Mana: " + _mana);

        }
    }

    void Update()
    {
        _mana += 1; 
    }
}
