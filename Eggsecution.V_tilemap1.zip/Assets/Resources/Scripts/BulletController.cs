using UnityEngine;

public class BulletController : MonoBehaviour
{
    [SerializeField] private float _speed = 5f;
    [SerializeField] private float _timeToDestroy = 3.5f;

    private void Start()
    {
        Invoke(nameof(Destroy), _timeToDestroy);
    }

    private void Update()
    {
        transform.Translate(_speed * Time.deltaTime * Vector3.right);
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }
}