using UnityEngine;
// Aceituna Dispara a distancia (falta agregar patron de dsiparo y de movimiento)
public class Aceituna : Enemigo
{
    [SerializeField] private GameObject _balaAceituna;
    [SerializeField] private float _speed = 1f;
    [SerializeField] private float _distanciaAtaque = 4f; 
    [SerializeField] private float _tiempoEntreDisparos = 5f;
    [SerializeField] private float _spawnDistance = 0.5f;
    private float _siguienteDisparo;

    protected override void Comportamiento()
    {
        if (_objetivo == null)
        {
            Detener();
            return;
        }
        float distancia = Vector2.Distance(transform.position, _objetivo.position);
        if (distancia > _distanciaAtaque)
        {
            MoverHacia(_objetivo.position, _speed);
        }
        else
        {
            Detener();
            if (Time.time >= _siguienteDisparo)
            {
                Disparar();
                _siguienteDisparo = Time.time + _tiempoEntreDisparos;
            }
        }
    }

    private void Disparar()
    {
        Debug.Log(name + " dispara a " + _objetivo.name);

        
        GameObject bala = CrearHacia(_balaAceituna, _objetivo, _spawnDistance);

 
    }

    protected override void OnDrawGizmosSelected()
    {
        base.OnDrawGizmosSelected();
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, _distanciaAtaque);
    }
}
