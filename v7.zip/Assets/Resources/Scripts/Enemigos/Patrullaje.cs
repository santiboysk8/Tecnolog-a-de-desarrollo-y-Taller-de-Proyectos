using Unity.VisualScripting;
using UnityEngine;

public class Patrullaje : MonoBehaviour
{
    [SerializeField] private float _movementSpeed = 2f;
    [SerializeField] private Transform[] _puntosMovimiento;
    [SerializeField] private float _minimumDistance;

    private int _siguientePaso = 0;
    private SpriteRenderer _spriteRenderer;

    private void Start()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        Girar();
    }
    private void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, _puntosMovimiento[_siguientePaso].position, _movementSpeed * Time.deltaTime);

        if(Vector2.Distance(transform.position, _puntosMovimiento[_siguientePaso].position) < _minimumDistance)
        {
            _siguientePaso += 1;
            if(_siguientePaso >= _puntosMovimiento.Length)
            {
                _siguientePaso = 0;
            }
            Girar();
        }
    }

    private void Girar()
    {
        if(transform.position.x < _puntosMovimiento[_siguientePaso].position.x)
        {
            _spriteRenderer.flipX = true;
        }
        else
        {
            _spriteRenderer.flipX = false;
        }
    }
}
